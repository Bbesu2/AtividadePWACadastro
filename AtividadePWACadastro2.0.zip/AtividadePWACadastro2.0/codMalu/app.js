// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-analytics.js";
import FirebaseAuthService from "./authService";

const firebaseConfig = {
  apiKey: "AIzaSyAXI-PjsWDmwddmlt6DnfF4M4pC59XDS7o",
  authDomain: "aulapwahambuguermenu.firebaseapp.com",
  projectId: "aulapwahambuguermenu",
  storageBucket: "aulapwahambuguermenu.firebasestorage.app",
  messagingSenderId: "1056583419682",
  appId: "1:1056583419682:web:92b22388925334008dc77b",
  measurementId: "G-MNMPRFEDRT"
};

fbApp = initializeApp(firebaseConfig);
window.analytics = getAnalytics(window.fbApp);
console.log(fbApp);

const auth = getAuth(fbApp);

// Inicializar Firebase
const fbApp = initializeApp(firebaseConfig);
getAnalytics(fbApp);

const authService = new FirebaseAuthService(fbApp);

// Captura do formulário
document.addEventListener("DOMContentLoaded", () => {
  const formulario = document.getElementById("cadastroForm");

  formulario.addEventListener("submit", (event) => {
    event.preventDefault();

    const email = document.getElementById("emailCad").value;
    const senha = document.getElementById("senhaCad").value;

    //mandando dados do form para o FireBase
    const FirebaseAuthService = new FireBaseAuthService(window.fbApp);
    FirebaseAuthService.criarUsuarioComEmailESenha(email, senha);
    //se o login ocorrer de forma correta ira levar o usuario a pagina de perfil
      if (FirebaseAuthService.criarUsuarioComEmailESenha(email, senha) = erro)
      {console.log("Erro")} else{
        document.getElementById("Enviar").addEventListener("click",() => {
  window.location.href = "perfil.html"})}

});
});


