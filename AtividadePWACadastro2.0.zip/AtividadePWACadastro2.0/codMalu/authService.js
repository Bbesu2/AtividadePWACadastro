import { 
    getAuth, 
    createUserWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";


    const auth = getAuth(app);

        return createUserWithEmailAndPassword(auth, email, senha)
            .then((credencial) => {
                console.log("Usuário criado:", credencial.user);
                return { sucesso: true, usuario: credencial.user };
            })
            .catch((erro) => {
                console.error("Erro ao criar usuário:", erro);
                return { sucesso: false, erro };
            });
    


export default FirebaseAuthService;

