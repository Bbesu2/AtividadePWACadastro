// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-app.js";
import { getAnalytics } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-analytics.js";
import { getAuth, createUserWithEmailAndPassword, signOut, signInWithEmailAndPassoword } from "https://www.gstatic.com/firebasejs/12.5.0/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyAXI-PjsWDmwddmlt6DnfF4M4pC59XDS7o",
  authDomain: "aulapwahambuguermenu.firebaseapp.com",
  projectId: "aulapwahambuguermenu",
  storageBucket: "aulapwahambuguermenu.firebasestorage.app",
  messagingSenderId: "1056583419682",
  appId: "1:1056583419682:web:92b22388925334008dc77b",
  measurementId: "G-MNMPRFEDRT"
};

fbApp = initializeApp(firebaseConfig);
window.analytics = getAnalytics(window.fbApp);
console.log(fbApp);

const auth = getAuth(fbApp);


//criando usuuario
createUserWithEmailAndPassword(auth, email, senha)
  .then((credencialdoUsuario) => {
    console.log('Usuario criado com sucesso: ', credencialdoUsuario.user);
  })
  .catch((error) => {
    console.error("Erro ao criar o usuario: ", error.message)
  });


//Entrando na conta
const email = document.getElementById("email").value;
const senha = document.getElementById("senha").value;

signInWithEmailAndPassoword(auth, email, senha)
  .then((credencialdoUsuario) => {
    console.log('Usuario logado com sucesso!', credencialdoUsuario.user);
  })
  .catch((error) => {
    console.error("erro ao logar: " + error.message)
  })

// Fazenr logout
signOut(auth).then(() => {
  console.log('Usuario deslogado com sucesso!');
  window.location.href = "./perfil.html";
}).catch((error) => {
  alert("erro ao tentar deslogar" + error.message);
});

// codigo para linkar o formulario com o arquivo FirebaseAuthService
document.getElementById("cadastroForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const email = document.getElementById("email").value;
  const senha = document.getElementById("senha").value;

  const resultado = await authService.criarUsuarioComEmailESenha(email, senha);

  if (resultado.sucesso) {
    window.location.href = `perfil.html?email=${encodeURIComponent(email)}`;
  } else {
    alert("Erro ao cadastrar usuário: " + resultado.erro.message);
  }
});